1. sound and video clips for experiment and user study correspond to Fig. 5,6,7 (directory)
2. sound variation after fracuture corresponds to Fig. 8 (fracture.mp4).